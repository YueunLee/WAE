from .base import Autoencoder
from .wae import WAE_MMD, WAE_GAN, WAE_GAN2, WAE_KL