from .dataset import load_dset
from .anneal import none_anneal, linear_anneal, exponential_anneal
from .mmd import mmd_penalty